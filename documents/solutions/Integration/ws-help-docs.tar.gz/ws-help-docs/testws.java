/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.eai.fas.ws.producer.ledger;

import com.finlogic.eai.ws.consumer.fas.FasLedgerConsumer;
import com.finlogic.eai.ws.consumer.ecommunication.EmailConsumer;
import com.finlogic.util.persistence.ConditionDefiner;
import java.util.List;

/**
 *
 * @author njuser
 */
public class Kinjal_test
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception
    {

        Kinjal_test test = new Kinjal_test();
        
        test.LedgerEntry();
        
        test.sendEmail();
        
        System.out.println(" delete ledger :"+test.deleteLedger());
        
        System.out.println("update ledger :"+test.updateLedger());
        
        System.out.println("get ledger List : "+test.getLedgerList());
        
    }

    public void LedgerEntry() throws Exception
    {
        FasLedgerConsumer fc = new FasLedgerConsumer();
        try
        {

            FasLedgerEntityBean fasLedgerEntityBean = new FasLedgerEntityBean();
            
            fasLedgerEntityBean.setTRDATE("01/01/2011"); 
            fasLedgerEntityBean.setDEBIT_ACCODE("A"); 
            fasLedgerEntityBean.setCREDIT_ACCODE("B"); 
            fasLedgerEntityBean.setDESCRIPTION("Desc"); 
            fasLedgerEntityBean.setTRANSACTION_TYPE("JV"); 
            fasLedgerEntityBean.setPRODUCT_TYPE("MF"); 
            fasLedgerEntityBean.setUSERNAME("B0040"); 
            fasLedgerEntityBean.setACTION_BY("ADMIN"); 
            fasLedgerEntityBean.setCOMPANY_ID("29"); 
            fasLedgerEntityBean.setAMOUNT(100); 
            System.out.println("vou is :"+ fc.insertLedger(fasLedgerEntityBean));
                        
        }
        catch (Exception e)
        {
            System.out.println("error is: "+e.getMessage());
        }
    }

    public void sendEmail() throws Exception
    {
        String key[] = new String[5];
        String val[] = new String[5];
            
            key[0]="templateId";
            val[0]="4";
            key[1]="to";
            val[1]="kinjal.bhoiwala@finlogicindia.in";
            key[2]="contentValues";
            val[2]="#name=value#";
            key[3]="mailFromServer";
            val[3]="njimage";
            val[4]="test_kinjal";
            key[4]="subjectValues";        
        
        System.out.println("sendMail is :"+new EmailConsumer().sendEmail(key,val));
    }

    public int updateLedger() throws Exception
    {
        FasLedgerEntityBean fleb = new FasLedgerEntityBean();
        FasLedgerConsumer flc = new FasLedgerConsumer();
        ConditionDefiner c = new ConditionDefiner();
        ConditionDefiner [] cd = new ConditionDefiner[1];
        fleb.setAMOUNT(123);
        c.setConditionField("vou");
        c.setConditionValue("123456");
        c.setOperator(ConditionDefiner.EQUALS);
        cd[0] = c;
        return flc.updateLedger(fleb, cd);
    }

    public int deleteLedger() throws Exception
    {
        FasLedgerConsumer flc = new FasLedgerConsumer();
        ConditionDefiner c = new ConditionDefiner();
        ConditionDefiner [] cd = new ConditionDefiner[1];
        c.setConditionField("vou");
        c.setConditionValue("123456");
        c.setOperator(ConditionDefiner.IS_NULL);
        cd[0] = c;
        return flc.deleteLedger(cd);
    }

    public List<FasLedgerEntityBean> getLedgerList() throws Exception
    {
        FasLedgerConsumer flc = new FasLedgerConsumer();
        ConditionDefiner c = new ConditionDefiner();
        ConditionDefiner [] cd = new ConditionDefiner[1];

        c.setConditionField("vou");
        c.setConditionValue("123456");
        c.setOperator(ConditionDefiner.LESS_THAN_EQUALS);
        cd[0] = c;
        return flc.getLedgerList(cd);
    }

}
