<?php

require('/var/www/html/integrationsolution/SmsServiceConsumer.php');
require('/var/www/html/integrationsolution/EmailServiceConsumer.php');
require('/var/www/html/integrationsolution/LedgerServiceConsumer.php');


//Sms Service
$smsServiceConsumer=new SmsServiceConsumer();

$map1=array("userName"=>"kinjal","userType"=>"tester","userCode"=>"k0001","moduleName"=>"intSolution","smsNature"=>"D","templateIdOrSmsText"=>"kinjal");

$map2=array("trxnId"=>"1234","smsValues"=>"hello","scheduleTime"=>"1312193943","recipientNumber"=>"9825071162");

$map3=array("templateIdOrSmsText"=>"jfdlkjsda","smsValues"=>"sdfsaf","recipientNumber"=>"9825015264","userName"=>"kinjal","smsNature"=>"D");

echo("Out=".$smsServiceConsumer->getBulkSmsNumber($map1));
echo("Out=".$smsServiceConsumer->writeBulkSmsFile($map2));
echo("Out=".$smsServiceConsumer->sendSingleSms($map3));
echo("Out=".$smsServiceConsumer->closeBulkSmsFile(84));
echo("Out=".$smsServiceConsumer->checkUser("Username"));
echo("Out=".$smsServiceConsumer->getCredits("UserName"));


//Email Service
$emailServiceConsumer=new EmailServiceConsumer();

$map4=array("templateId"=>1,"to"=>"kinjal.bhoiwala@finlogicindia.in","subjectValues"=>"test","mailFromServer"=>"finserver","contentValues"=>"#name=value#");

echo("Out=".$emailServiceConsumer->sendMail($map4));




//LEdger Service getLedgerList()
	$ledgerCons  = new LedgerServiceConsumer();
        $cnArr=array();
        
        $cn = new ConditionDefiner();
        $cn->setOperator($cn->EQUALS);
        $cn->setConditionField("LEDGER.VOU");
        $cn->setConditionValue("BAN0000798");        
        array_push($cnArr, $cn);
        
        $cn1 = new ConditionDefiner();
        $cn1->setOperator($cn->EQUALS);
        $cn1->setConditionField("LEDGER.ACCODE");
        $cn1->setConditionValue("H0001");        
        array_push($cnArr, $cn1);        
        
        echo("<pre>");
        print_r($ledgerCons->getLedgerArray($cnArr));
        echo("</pre>");

?>
